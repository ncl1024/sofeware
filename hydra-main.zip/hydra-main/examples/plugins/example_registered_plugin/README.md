# Hydra example plugin via `Plugins.register`
This plugin is not very useful, but it demonstrates how to register a plugin using the `Plugins.register` method.