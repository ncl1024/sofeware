# Hydra example plugin
this plugin is not very useful, but demonstrates the plugin discovery capability of Hydra.

Core plugins (Plugins that are developed jointly with Hydra) lives in the plugins subdirectory inside the Hydra repo.
Third party plugins can live anywhere (public or private Github repos, Organizations in-house SCM etc)