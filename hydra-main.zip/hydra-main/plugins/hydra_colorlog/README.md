# Hydra colorlog
Adds <a class="external" href="https://github.com/borntyping/python-colorlog" target="_blank">colorlog</a> colored logs for `hydra/job_logging` and `hydra/hydra_logging`.

See [website](https://hydra.cc/docs/plugins/colorlog) for more information
