# Hydra Ax Sweeper
Provides a [`Ax Sweeper`](https://ax.dev/) based Hydra Sweeper supporting parallel execution.

See [website](https://hydra.cc/docs/plugins/ax_sweeper/) for more information
