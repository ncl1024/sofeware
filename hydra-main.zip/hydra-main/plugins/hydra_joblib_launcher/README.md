# Hydra Joblib Launcher
Provides a [`Joblib.Parallel`](https://joblib.readthedocs.io/en/latest/parallel.html) based Hydra Launcher supporting parallel execution.

See [website](https://hydra.cc/docs/plugins/joblib_launcher) for more information
