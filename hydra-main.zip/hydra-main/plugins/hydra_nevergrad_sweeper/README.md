# Hydra Nevergrad Sweeper plugin

Provides a mechanism for Hydra applications to use [Nevergrad](https://github.com/facebookresearch/nevergrad) algorithms for the optimization of the parameters of any experiment.

See [website](https://hydra.cc/docs/plugins/nevergrad_sweeper) for more information