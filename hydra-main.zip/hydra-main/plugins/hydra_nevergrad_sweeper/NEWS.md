1.2.0 (2022-05-17)
======================

### Features

- Add fault tolerance via `max_failure_rate` parameter ([#1545](https://github.com/facebookresearch/hydra/issues/1545))


1.1.5 (2021-06-10)
==================

### Features

- Enable support of Python 3.9 . ([#1206](https://github.com/facebookresearch/hydra/issues/1206))
- Change default optimizer to NGOpt ([#1374](https://github.com/facebookresearch/hydra/issues/1374))


1.1.0rc2 (2021-03-30)
=====================

### Maintenance Changes

- Pin Hydra 1.0 plugins to hydra-core==1.0.* to discourage usage with Hydra 1.1 ([#1501](https://github.com/facebookresearch/hydra/issues/1501))
