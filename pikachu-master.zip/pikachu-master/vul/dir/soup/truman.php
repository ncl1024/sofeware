
<?php
$html=<<<A
<pre>
Good morning,
and in case I don't see ya, 
good afternoon, good evening, and good night!
</pre>
A;
?>

