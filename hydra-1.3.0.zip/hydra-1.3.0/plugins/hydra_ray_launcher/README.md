# Hydra Ray Launcher
Provides a [`Ray`](https://docs.ray.io/en/latest/) based Hydra Launcher supporting execution on AWS.

See [website](https://hydra.cc/docs/plugins/ray_launcher) for more information
